#!/bin/sh
cd /usr/share/games/nlarn
./nlarn
