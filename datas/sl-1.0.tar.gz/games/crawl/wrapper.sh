#!/bin/sh

exec /usr/share/games/bin/$( basename $0 ) "$@"
