#!/bin/bash

cd /usr/share/javacpc
java -jar JavaCPC.jar
