#!/bin/sh

cd /usr/share/games/astromenace
./astromenace
