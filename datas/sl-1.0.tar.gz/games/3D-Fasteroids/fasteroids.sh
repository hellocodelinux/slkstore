#!/bin/sh
cd /usr/share/games/3d-fasteroids
./fasteroids
