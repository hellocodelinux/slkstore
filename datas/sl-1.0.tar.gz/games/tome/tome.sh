#!/bin/sh
cd /usr/share/games/tome
./t-engine
