. /opt/OpenFOAM/OpenFOAM-11/etc/bashrc
