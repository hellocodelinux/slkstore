#load the path to the R libraries to enable linking
ldconfig
