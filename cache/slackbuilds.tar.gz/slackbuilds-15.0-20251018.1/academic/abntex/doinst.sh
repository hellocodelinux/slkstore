chroot . /usr/share/texmf/bin/texhash
