# profile.d script for SBo flac-opt build, WTFPL, B. Watson.

MANPATH="@PREFIX@/man:$MANPATH"
PATH=@PREFIX@/bin:$PATH

export PATH
export MANPATH
