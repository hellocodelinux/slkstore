[ -x /sbin/setcap ] && /sbin/setcap cap_ipc_lock,cap_sys_nice=ep usr/bin/foo-yc20
[ -x /sbin/setcap ] && /sbin/setcap cap_ipc_lock,cap_sys_nice=ep usr/bin/foo-yc20-cli
