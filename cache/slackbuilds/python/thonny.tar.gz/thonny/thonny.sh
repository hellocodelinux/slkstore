#!/bin/sh
cd /opt
exec python3 -m thonny "$@"
