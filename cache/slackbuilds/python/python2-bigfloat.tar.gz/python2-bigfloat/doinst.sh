#!/bin/bash

python -m bigfloat.test.test_bigfloat
