echo
echo "********************* NOTICE **********************"
echo "Cups needs restarting for new drivers to be usable:"
echo "/etc/rc.d/rc.cups restart"
echo "***************************************************"
echo
