( cd usr/bin && unlink brprintconf_dcpl8410cdw )
