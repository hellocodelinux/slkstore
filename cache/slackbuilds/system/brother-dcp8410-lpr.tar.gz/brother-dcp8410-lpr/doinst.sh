( cd usr/bin && rm -rf brprintconf_dcpl8410cdw )
( cd usr/bin && ln -sf /opt/brother/Printers/dcpl8410cdw/lpd/brprintconf_dcpl8410cdw brprintconf_dcpl8410cdw )
