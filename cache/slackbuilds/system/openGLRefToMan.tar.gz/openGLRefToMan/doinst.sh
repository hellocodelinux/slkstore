mandb -c     # update index database used by 'whatis'
