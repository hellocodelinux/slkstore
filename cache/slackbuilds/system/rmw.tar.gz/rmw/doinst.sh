DEPRECATED="etc/rmwrc"
if [ -f "$DEPRECATED" ]; then
  rm "$DEPRECATED"
fi
