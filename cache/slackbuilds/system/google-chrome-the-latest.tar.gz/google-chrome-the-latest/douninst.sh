rm -rf /opt/google-chrome-the-latest
