#!/bin/sh

kwriteconfig5 --file kded5rc --group "Module-kscreen" --key autoload --type bool true
