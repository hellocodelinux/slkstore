#! /bin/bash

export ZOO_LOG_DIR=/var/log/zookeeper
export ZOO_LOG4J_PROP=INFO,ROLLINGFILE
