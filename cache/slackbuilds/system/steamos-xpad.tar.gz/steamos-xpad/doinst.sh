chroot . /sbin/depmod -a @KERNEL@ 2>/dev/null
