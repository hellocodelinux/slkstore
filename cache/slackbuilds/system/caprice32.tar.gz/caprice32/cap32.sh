#!/bin/sh
cd /usr/share/caprice32
./cap32 $1
