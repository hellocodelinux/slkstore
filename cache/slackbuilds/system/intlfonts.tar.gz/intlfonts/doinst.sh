#!/bin/bash
fc-cache
