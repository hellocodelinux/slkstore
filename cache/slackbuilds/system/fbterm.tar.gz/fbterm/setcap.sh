[ -x /sbin/setcap ] && /sbin/setcap cap_sys_admin,cap_sys_tty_config=ep usr/bin/fbterm
