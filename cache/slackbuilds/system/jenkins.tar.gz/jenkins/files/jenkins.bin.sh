#!/bin/sh
java -jar /usr/share/jenkins/jenkins.war ${1+"$@"}
