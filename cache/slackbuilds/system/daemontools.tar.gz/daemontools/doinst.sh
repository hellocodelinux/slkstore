chroot . sh -c "cd /package/admin/daemontools;./package/run"
