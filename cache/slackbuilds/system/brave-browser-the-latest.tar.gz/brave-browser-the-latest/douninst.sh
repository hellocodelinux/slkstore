rm -rf /opt/brave-browser-the-latest
