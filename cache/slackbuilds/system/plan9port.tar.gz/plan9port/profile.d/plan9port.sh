#!/bin/sh
export PLAN9=/opt/plan9
export MANPATH="$MANPATH:$PLAN9/man"
export PATH="$PATH:$PLAN9/bin"
