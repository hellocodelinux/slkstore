cd usr/share/fonts/OTF
mkfontscale
mkfontdir
fc-cache -f
