grep -q '^/bin/v7sh$' etc/shells 2>/dev/null || echo '/bin/v7sh' >> etc/shells
