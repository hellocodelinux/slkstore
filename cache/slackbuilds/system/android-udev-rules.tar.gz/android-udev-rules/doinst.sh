if [ -f /etc/udev/rules.d/51-android.rules ]; then
    chmod a+r /etc/udev/rules.d/51-android.rules
fi

