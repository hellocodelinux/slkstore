grep -q '^/bin/etsh$' etc/shells 2>/dev/null || echo "/bin/etsh" >> etc/shells
