#!/bin/sh

cd /usr/share/games/assaultcube-reloaded
./client.sh
