#!/bin/sh

cd /usr/share/games/assaultcube-reloaded
./server.sh
