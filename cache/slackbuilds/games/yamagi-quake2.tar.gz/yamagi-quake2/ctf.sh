#!/bin/sh
exec /usr/share/games/quake2/quake2 +set basedir /usr/share/games/quake2 +set game ctf $*
