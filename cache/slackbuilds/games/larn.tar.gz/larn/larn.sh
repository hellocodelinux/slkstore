#!/bin/sh
cd /usr/share/games/larn
exec /usr/share/games/larn/larn "$@"
