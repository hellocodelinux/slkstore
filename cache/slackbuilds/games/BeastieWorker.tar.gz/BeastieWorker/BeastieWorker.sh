#!/bin/sh
cd /usr/share/games/BeastieWorker
./BeastieWorker
