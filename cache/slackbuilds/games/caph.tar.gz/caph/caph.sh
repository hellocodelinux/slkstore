#!/bin/bash

cd /usr/share/games/caph
./caph
