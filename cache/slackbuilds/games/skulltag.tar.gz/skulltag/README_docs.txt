
Skulltag doesn't ship with any documentation. Instead, use the Skulltag Wiki
at http://www.skulltag.com/ for all your documentation needs.
