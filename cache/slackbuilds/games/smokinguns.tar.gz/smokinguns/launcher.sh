#!/bin/sh
cd /opt/smokinguns
./smokin
