#!/bin/sh

cd /usr/share/games/1945
./game_1945
