#!/bin/bash
LD_LIBRARY_PATH=/usr/libexec/gargoyle:$LD_LIBRARY_PATH /usr/libexec/gargoyle/gargoyle $*
