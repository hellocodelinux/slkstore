#!/bin/sh
cd /usr/share/games/npush
./npush
