chroot . /usr/bin/ghc-pkg recache

