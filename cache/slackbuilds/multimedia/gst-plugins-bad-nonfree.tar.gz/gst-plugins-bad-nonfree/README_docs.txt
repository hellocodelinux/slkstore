If you're looking for the documentation, see:

/usr/doc/gst-plugins-bad-free-*/
