#!/bin/bash

cd /opt/smath-studio
exec mono ./SMathStudio_Desktop.exe "$@"
