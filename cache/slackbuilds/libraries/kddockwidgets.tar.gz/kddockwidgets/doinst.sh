( cd usr/lib64 ; rm -rf libkddockwidgets.so )
( cd usr/lib64 ; ln -sf libkddockwidgets.so.1.7 libkddockwidgets.so )
( cd usr/lib64 ; rm -rf libkddockwidgets.so.1.7 )
( cd usr/lib64 ; ln -sf libkddockwidgets.so.1.7.0 libkddockwidgets.so.1.7 )
