#!/bin/sh
export MANPATH="/opt/diet/man:$MANPATH"
