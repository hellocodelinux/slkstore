chroot . /usr/bin/guile1.8 -q -s /usr/libexec/slib/guile-slibcat.script
