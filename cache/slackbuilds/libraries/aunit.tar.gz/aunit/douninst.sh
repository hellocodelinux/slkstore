if [ -x /usr/sbin/update-info-dir -a -d usr/info ]; then
	/usr/sbin/update-info-dir
fi
