#!/bin/bash
#Script to start Fritzing in parts directory.

cd /usr/share/fritzing/parts
exec /usr/bin/fritzing
