#!/bin/sh
LDRAWDIR=/usr/share/LDRAW ldglite_bin $1
