#!/bin/sh
exec java -jar /usr/share/yed/yed.jar
