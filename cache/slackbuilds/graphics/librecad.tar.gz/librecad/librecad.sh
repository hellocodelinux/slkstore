#!/bin/sh

exec /opt/librecad/librecad "$@"
