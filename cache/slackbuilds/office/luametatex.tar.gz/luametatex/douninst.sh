cd /opt/context
rm -rf native
rm texmf-config
rm texmf-dist
rm texmf-local
rm -rf texmf-var/luametatex-cache
rm texmf-var
cd ..
rm -rf context
