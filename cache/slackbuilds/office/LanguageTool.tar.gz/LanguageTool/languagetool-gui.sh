#!/bin/sh

cd /usr/share/LanguageTool/
java -jar languagetool.jar
