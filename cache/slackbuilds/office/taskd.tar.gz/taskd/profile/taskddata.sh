#!/bin/sh
#Set data path for taskd server from global config

. /etc/taskddata
