#!/bin/sh

export SAL_USE_VCLPLUGIN=gtk
