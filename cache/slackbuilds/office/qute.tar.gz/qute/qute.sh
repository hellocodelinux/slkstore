#!/bin/sh
cd /usr/share/qute
./Qute
