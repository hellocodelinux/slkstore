int is_selinux_enabled(void)
{
    return 0;
}
