echo -e
echo "For syncing from the mirror every hour by cron, run:"
echo -e
echo "  chmod 755 /etc/cron.hourly/kasp_update.sh"
echo -e

