# THANKS

Thank you to the following contributors, who have helped make Amfora great. FOSS projects are a community effort, and we would be worse off without you.

* Sotiris Papatheodorou (@sotpapathe)
* Chloe Kudryavtsev (@CosmicToast)
* Adrian Hesketh (@a-h)
* Jansen Price (@sumpygump)
* Alex Wennerberg (@alexwennerberg)
* Timur Ismagilov (@bouncepaw)
* Matt Caroll (@ohiolab)
* Patryk Niedźwiedziński (@pniedzwiedzinski)
* Trevor Slocum (@tsclocum)
* Mattias Jadelius (@jedthehumanoid)
* Lokesh Krishna (@lokesh-krishna)
* Jeff (@phaedrus-jaf)
* Stephen Robinson (@sudobash1)
* Peter Steinberg (@objectliteral)
* Thomas Adam (@ThomasAdam)
* @lostleonardo
* Himanshu (@singalhimanshu)
* @regr4
* Anas Mohamed (@amohamed11)
* David Jimenez (@dvejmz)
* Michael McDonagh (@m-mcdonagh)
* mooff (@awfulcooking)
* Josias (@justjosias)
* mntn (@mntn-xyz)
* Maxime Bouillot (@Arkaeriit)
* Emily (@emily-is-my-username)
* Autumn! (@autumnull)
* William Rehwinkel (@FiskFan1999)
