#!/bin/bash

curl "https://www.betterbird.eu/downloads/getloc.php?os=linux&lang=en-US&version=release"
echo ""
