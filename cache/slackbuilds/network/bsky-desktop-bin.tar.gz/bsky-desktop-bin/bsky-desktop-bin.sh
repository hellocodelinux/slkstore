#!/bin/bash

/opt/bsky-desktop/bskyDesktop-*.AppImage

