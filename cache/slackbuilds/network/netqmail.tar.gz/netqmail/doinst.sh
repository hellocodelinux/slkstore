chroot . /bin/sh /usr/doc/netqmail-1.06/install_scripts/doinst_sh
