#!/bin/sh
/usr/bin/msfupdate >> /var/log/msfupdate.log 2>&1
