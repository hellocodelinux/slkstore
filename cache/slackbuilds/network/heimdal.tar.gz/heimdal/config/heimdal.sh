#!/bin/sh

export PATH=/usr/heimdal/bin:/usr/heimdal/sbin:$PATH
export MANPATH=/usr/heimdal/man:$MANPATH
