rm /usr/bin/prlinuxcupsppd
rm /usr/lib64/cupsPPD/prlinuxcupsppd
rmdir --ignore-fail-on-non-empty /usr/lib64/cupsPPD
