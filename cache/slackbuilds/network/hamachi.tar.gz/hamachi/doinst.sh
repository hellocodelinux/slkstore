/usr/bin/ln -sf /usr/share/hamachi/hamachid /usr/bin/hamachi

