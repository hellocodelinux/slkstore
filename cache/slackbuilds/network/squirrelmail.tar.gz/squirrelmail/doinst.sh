chown apache:apache /var/lib/squirrelmail/prefs /var/spool/squirrelmail/attach
chmod 0700 /var/lib/squirrelmail/prefs /var/spool/squirrelmail/attach
