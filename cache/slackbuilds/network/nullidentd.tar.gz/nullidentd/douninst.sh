if [ -x usr/bin/mandb ]; then
  chroot . /usr/bin/mandb &> /dev/null
fi
