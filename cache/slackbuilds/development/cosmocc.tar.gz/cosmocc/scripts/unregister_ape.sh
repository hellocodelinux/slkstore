
# unregister APE loader
echo -1 > /proc/sys/fs/binfmt_misc/cli
echo -1 > /proc/sys/fs/binfmt_misc/status

