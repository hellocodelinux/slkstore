#!/bin/sh

exec /opt/cosmocc/bin/$( basename $0 ) "$@"
