#!/bin/bash

#LD_LIBRARY_PATH=/opt/lm-studio-bin:$LD_LIBRARY_PATH
/opt/LM-Studio-*.AppImage
#--no-sandbox
