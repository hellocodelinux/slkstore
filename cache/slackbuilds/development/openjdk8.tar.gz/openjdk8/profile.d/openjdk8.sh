#!/bin/sh
export JAVA_HOME=/usr/lib/openjdk8
export MANPATH="${MANPATH}:${JAVA_HOME}/man"
export PATH="${PATH}:${JAVA_HOME}/bin:${JAVA_HOME}/jre/bin"
