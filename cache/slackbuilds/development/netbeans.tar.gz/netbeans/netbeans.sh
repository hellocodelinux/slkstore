#!/bin/bash
cd ${HOME}
/opt/netbeans/bin/netbeans $@
