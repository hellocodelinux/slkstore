#!/bin/sh
export GRADLE_HOME=/usr/share/gradle
