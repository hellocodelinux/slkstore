#!/bin/bash

export PATH="/opt/cmake-opt/bin/:$PATH"
