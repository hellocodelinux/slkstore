#!/bin/sh

export LIQUIBASE_HOME=/opt/liquibase
