#!/bin/sh
export JAVA_HOME=/usr/lib/zulu-openjdk6
export MANPATH="${JAVA_HOME}/man:${MANPATH}"
export PATH="${JAVA_HOME}/bin:${JAVA_HOME}/jre/bin:${PATH}"
