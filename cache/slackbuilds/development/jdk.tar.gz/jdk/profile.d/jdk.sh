#!/bin/sh
export JAVA_HOME=/usr/lib/java
export PATH="${PATH}:${JAVA_HOME}/bin:${JAVA_HOME}/jre/bin"
