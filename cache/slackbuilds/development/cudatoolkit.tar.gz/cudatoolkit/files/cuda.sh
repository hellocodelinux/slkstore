#!/bin/sh
export PATH="${PATH}:/usr/share/cuda/bin"
