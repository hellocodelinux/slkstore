[ -x usr/bin/file -a -x etc/file/recompile_magic.mgc.sh ] && \
  etc/file/recompile_magic.mgc.sh &>/dev/null
