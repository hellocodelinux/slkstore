if [ -x usr/bin/mandb ]; then
  usr/bin/mandb &> /dev/null
fi
