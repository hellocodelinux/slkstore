rm -rf /opt/gnatstudio
