#!/bin/sh
export PATH=$PATH:/opt/gnatstudio/bin
export GNATSTUDIO_DOC_PATH=/opt/gnatstudio/share/doc/gnatstudio/html
