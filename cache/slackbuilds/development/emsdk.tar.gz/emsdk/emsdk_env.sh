#!/bin/sh

source /usr/libLIBDIRSUFFIX/emsdk/emsdk_env.sh
