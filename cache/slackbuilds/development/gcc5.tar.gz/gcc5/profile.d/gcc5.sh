export CC=gcc-5
export CPP=cpp-5
export CXX=g++-5
export AR=gcc-ar-5
export NM=gcc-nm-5
export RANLIB=gcc-ranlib-5

