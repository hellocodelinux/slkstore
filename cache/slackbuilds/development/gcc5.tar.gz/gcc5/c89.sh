#!/bin/sh
fl="-std=c89"
CC=${CC:-"gcc"}
for opt; do
  case "$opt" in
    -ansi|-std=c89|-std=iso9899:1990) fl="";;
    -std=*) echo "`basename $0` called with non ANSI/ISO C option $opt" >&2
	    exit 1;;
  esac
done
exec $CC $fl ${1+"$@"}
