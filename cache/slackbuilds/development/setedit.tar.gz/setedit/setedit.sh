#!/bin/sh
# setup setedit lib path
export SET_LIBS=/usr/lib/setedit
