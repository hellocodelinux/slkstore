#!/bin/bash
cd ${HOME}
/opt/android-studio/bin/inspect.sh $@
