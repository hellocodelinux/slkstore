#!/bin/sh
export SCALA_HOME=@LIBDIR@/scala
