export SMLNJ_HOME=/usr/lib/smlnj
export PATH="$PATH:/usr/lib/smlnj/bin"
