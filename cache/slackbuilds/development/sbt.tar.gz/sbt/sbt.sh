#!/bin/sh

exec /usr/share/sbt/bin/sbt "$@"

