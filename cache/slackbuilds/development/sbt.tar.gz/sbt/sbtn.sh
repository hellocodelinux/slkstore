#!/bin/sh

exec /usr/share/sbt/bin/sbtn-x86_64-pc-linux "$@"

