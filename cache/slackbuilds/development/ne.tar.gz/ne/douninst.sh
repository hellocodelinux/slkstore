if [ -x /usr/sbin/update-info-dir ]; then
  /usr/sbin/update-info-dir &> /dev/null
fi
