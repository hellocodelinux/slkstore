#!/bin/sh
export PATH=${PATH}:/opt/mspgcc-legacy/bin
