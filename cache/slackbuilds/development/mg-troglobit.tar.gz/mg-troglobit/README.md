# mg-troglobit.SlackBuild

A SlackBuild for Joachim Wiberg (troglobit)'s fork of OpenBSD Mg (https://github.com/troglobit/mg)

The usage is the very same of https://slackbuilds.org/howto/

Get the Mg source code here: https://github.com/troglobit/mg/releases/download/v3.7/mg-3.7.tar.gz

![Mg-troglobit on Slackware 14.0](https://i.postimg.cc/P5BKVR8N/mg37.png "Mg-troglobit on Slackware 14.0")

## License
Copyright (c) 2020-2023 Saidone

Distributed under the MIT License
