#!/bin/bash
exec /opt/balena-etcher/lib/balena-etcher/balena-etcher
