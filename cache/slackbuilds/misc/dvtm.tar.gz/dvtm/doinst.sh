if [ -x /usr/bin/tic ]; then
  /usr/bin/tic -s usr/share/dvtm/dvtm.info >/dev/null 2>&1
fi
